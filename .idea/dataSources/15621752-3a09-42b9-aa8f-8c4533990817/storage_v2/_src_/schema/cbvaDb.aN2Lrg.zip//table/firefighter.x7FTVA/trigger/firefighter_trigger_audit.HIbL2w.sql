create trigger firefighter_trigger_audit
  after UPDATE
  on firefighter
  for each row
  BEGIN
      if NEW.rank_id <> OLD.rank_id  THEN
        INSERT into firefighter_audit(firefighter_id,message,update_date)  VALUES (OLD.id,concat("Change: rank [old]=",OLD.rank_id,",[new rank]= ",NEW.rank_id),now());
      end if;
    if NEW.active <> OLD.active  THEN
      INSERT into firefighter_audit(firefighter_id,message,update_date) VALUES (OLD.id,concat("Change: status [old]=",OLD.active,",[new status]= ",NEW.active),now());
    end if;
  end;

